package com.rc.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="MobileRecharge")
public class MobileRechargeBean {

	@Id
	@GeneratedValue
	private Integer rechargeId;
	
	private String planName;
	
	private Integer amount;
	
	
	private String mobileNo;
	private String discription;
	private String dor;


	public MobileRechargeBean() {


	}



	public MobileRechargeBean(Integer rechargeId, String planName, Integer amount,
			String mobileNo, String discription, String dor) {
		super();
		this.rechargeId = rechargeId;
		this.planName = planName;
		this.amount = amount;
		this.mobileNo = mobileNo;
		this.discription = discription;
		this.dor = dor;
	}



	public Integer getRechargeId() {
		return rechargeId;
	}
	public void setRechargeId(Integer rechargeId) {
		this.rechargeId = rechargeId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public String getDor() {
		return dor;
	}
	public void setDor(String date) {
		this.dor = date;
	}



	@Override
	public String toString() {
		return "rechargeId=" + rechargeId + ", planName="
				+ planName + ", amount=" + amount + ", mobileNo=" + mobileNo
				+ ", discription=" + discription + ", date=" + dor ;
	}

}
