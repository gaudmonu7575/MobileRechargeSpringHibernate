package com.rc.controller;

import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.rc.bean.MobileRechargeBean;
import com.rc.service.IServiceRecharge;

@Controller
public class RechargeController {

	@RequestMapping("home")
	public String getHomePage()
	{
		return "home";
	}

	@RequestMapping("recharge")
	public String rechargeMobile(Model m)
	{
		MobileRechargeBean mrb = new MobileRechargeBean();
		m.addAttribute("rechargeobj", mrb);
		return "rechargemobile";
	}

	@Autowired
	private IServiceRecharge iser;

	@RequestMapping(value="rechargeprocess",method=RequestMethod.POST)
	public String doRecharge(Model m,@ModelAttribute("rechargeobj") MobileRechargeBean mobean)
	{
		System.out.println("started");
		String target=null;
		
			//System.out.println("sending to service");
			Integer id = iser.addRecharge(mobean);
			//System.out.println("id taken"+id);
			if(id>0)
			{
				//System.out.println("in id > 0");
				m.addAttribute("id", id);
				target = "success";
			}
			else
			{
				//System.out.println("in else part");
				target = "home";
			}
		System.out.println("sending to "+target);

		return target;
	}


	@RequestMapping(value="viewall",method=RequestMethod.GET)
	public ModelAndView viewAllRecharge(Model m)
	{
		ModelAndView mv = new ModelAndView();
		ArrayList<MobileRechargeBean> arrylist = iser.viewall();
		mv.setViewName("details");
		mv.addObject("list", arrylist);

		return mv;
	}





}
