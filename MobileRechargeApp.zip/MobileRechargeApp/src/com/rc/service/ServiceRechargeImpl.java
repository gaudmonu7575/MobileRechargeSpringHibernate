package com.rc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rc.bean.MobileRechargeBean;
import com.rc.dao.IDAORecharge;

@Service
public class ServiceRechargeImpl implements IServiceRecharge{

	@Autowired
	private IDAORecharge daorc;
	
	@Override
	public Integer addRecharge(MobileRechargeBean mobean) {

		System.out.println("inside service");
		return daorc.addRecharge(mobean);
	}

	@Override
	public ArrayList<MobileRechargeBean> viewall() {
		
		return daorc.viewall();
	}

}
