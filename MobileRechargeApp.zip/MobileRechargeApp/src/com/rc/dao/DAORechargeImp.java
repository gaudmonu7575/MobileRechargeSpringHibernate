package com.rc.dao;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.rc.bean.MobileRechargeBean;

@Repository
@Transactional
public class DAORechargeImp implements IDAORecharge{

	@PersistenceContext
	private EntityManager em;

	@Override
	public Integer addRecharge(MobileRechargeBean mobean) {

		//System.out.println("in dao");
		em.persist(mobean);
		//System.out.println("query fired");
		return mobean.getRechargeId();
	}

	@Override
	public ArrayList<MobileRechargeBean> viewall() {

		Query qry = em.createQuery("select s from MobileRechargeBean s");
		return (ArrayList<MobileRechargeBean>) qry.getResultList();
	}



}
