package com.rc.service;

import java.util.ArrayList;

import com.rc.bean.MobileRechargeBean;


public interface IServiceRecharge {

	public Integer addRecharge(MobileRechargeBean mobean);
	public ArrayList<MobileRechargeBean> viewall();
	
}
